package com.skillup.azure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureApplicationTests {

	@Test
	void contextLoads() {
	}

}
